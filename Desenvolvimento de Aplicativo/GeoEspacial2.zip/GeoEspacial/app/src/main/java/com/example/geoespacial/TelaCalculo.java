package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class TelaCalculo extends AppCompatActivity {
    static int formula;
    EditText et1, et2, et3;
    TextView campoResultado, ExibeNome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_calculo);
        getSupportActionBar().hide();
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);
        campoResultado = findViewById(R.id.resultado);
        ExibeNome = findViewById(R.id.ExibeNome);
        organizaTela();
    }
    public void organizaTela(){
        if (formula == 1){
            ExibeNome.setText("Área Total");
            et1.setHint("Digite a Área da Base");
            et2.setHint("Digite o numero de Faces");
            et3.setHint("Digite a area da face lateral");
        }
        else if (formula == 2){
            et1.setHint("Área da Base (pela Área Total)");
            et2.setHint("Numero de Faces Laterais");
            et3.setHint("Área das Faces Laterais");

        }
        else if (formula == 3){
            ExibeNome.setText("Área da Base (Pelo Volume)");
            et1.setHint("Volume");
            et2.setHint("Altura");
            et3.setVisibility(View.INVISIBLE);


        }
        else if (formula == 4){
            ExibeNome.setText("Número de Lados");
            et1.setHint("Área Total");
            et2.setHint("Área da Base");
            et3.setHint("Área da Face Lateral");


        }
        else if (formula == 5){
            ExibeNome.setText("Área da Face");
            et1.setHint("Área Total");
            et2.setHint("Área da Base");
            et3.setHint("Número de Faces Laterais");

        }
        else if (formula == 6){
            ExibeNome.setText("Volume");
            et1.setHint("Área da Base");
            et2.setHint("Altura");
            et3.setVisibility(View.INVISIBLE);

        }

        else if(formula == 7){
            ExibeNome.setText("Altura");
            et1.setHint("Volume");
            et2.setHint("Área da Base");
            et3.setVisibility(View.INVISIBLE);

        }

    }
    public void alberto(View view) {
        double conta;
        double a = Double.parseDouble(et1.getText().toString());
        double b = Double.parseDouble(et2.getText().toString());
        double c;

        switch (formula){
            case 1:
                c = Double.parseDouble(et3.getText().toString());
                conta = 2*a + b*c;
                campoResultado.setText(conta+ "");
                break;
            case 2 :
                c = Double.parseDouble(et3.getText().toString());
                conta = a - b*c / 2;
                campoResultado.setText(conta+ "");
                break;

            case 4 :
                c = Double.parseDouble(et3.getText().toString());
                conta = a - 2*b / c;
                campoResultado.setText(conta+ "");
                break;
            case 5:
                c = Double.parseDouble(et3.getText().toString());
                conta = a - 2*b / c;
                campoResultado.setText(conta+ "");
                break;

            case 3:
                conta = a / b;
                campoResultado.setText(conta+ "");
                break;

            case 6:
                conta = a*b;
                campoResultado.setText(conta+ "");
                break;

            case 7:
                conta = a/b;
                campoResultado.setText(conta+"");
                break;


        }

    }

}
package com.example.matriz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText zero_zero, zero_um, zero_dois, um_zero, um_um, um_dois, dois_zero, dois_um, dois_dois;
    Button calcular;
    TextView result;
    String str_zero_zero, str_zero_um, str_zero_dois, str_um_zero, str_um_um, str_um_dois, str_dois_zero, str_dois_um, str_dois_dois;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        zero_zero = findViewById(R.id.sete); // [0, 0]
        zero_um = findViewById(R.id.oito); // [0, 1]
        zero_dois = findViewById(R.id.nove); // [0, 2]
        um_zero = findViewById(R.id.quatro); // [1, 0]
        um_um = findViewById(R.id.cinco); // [1, 1]
        um_dois = findViewById(R.id.seis); // [1, 2]
        dois_zero = findViewById(R.id.um); // [2, 0]
        dois_um = findViewById(R.id.dois); // [2, 1]
        dois_dois = findViewById(R.id.tres); // [2, 2]
        calcular = findViewById(R.id.botao_calcular);
        result = findViewById(R.id.result);
        result.setVisibility(View.GONE);
    }
    public void checar_preenchimento(){
        str_zero_zero = zero_zero.getText().toString(); // converte os EditText para String
        str_zero_um = zero_um.getText().toString(); // converte os EditText para String
        str_zero_dois = zero_dois.getText().toString(); // converte os EditText para String
        str_um_zero = um_zero.getText().toString(); // converte os EditText para String
        str_um_um = um_um.getText().toString(); // converte os EditText para String
        str_um_dois = um_dois.getText().toString(); // converte os EditText para String
        str_dois_zero = dois_zero.getText().toString(); // converte os EditText para String
        str_dois_um = dois_um.getText().toString(); // converte os EditText para String
        str_dois_dois = dois_dois.getText().toString(); // converte os EditText para String
        if (!TextUtils.isEmpty(str_zero_zero) && !TextUtils.isEmpty(str_zero_um) &&
                !TextUtils.isEmpty(str_zero_dois) && !TextUtils.isEmpty(str_um_zero) &&
                !TextUtils.isEmpty(str_um_um) && !TextUtils.isEmpty(str_um_dois) &&
                !TextUtils.isEmpty(str_dois_zero) && !TextUtils.isEmpty(str_dois_um) &&
                !TextUtils.isEmpty(str_dois_dois)){
            calcular_determinante();
        } else{
            Toast.makeText(this, "Preencha todos os campos.", Toast.LENGTH_LONG).show();
        }
    }
    public void calcular_determinante(){
        int i_zero_zero = Integer.parseInt(str_zero_zero); // converte os EditText para int
        int i_zero_um = Integer.parseInt(str_zero_um); // converte os EditText para int
        int i_zero_dois = Integer.parseInt(str_zero_dois); // converte os EditText para int
        int i_um_zero = Integer.parseInt(str_um_zero); // converte os EditText para int
        int i_um_um = Integer.parseInt(str_um_um); // converte os EditText para int
        int i_um_dois = Integer.parseInt(str_um_dois); // converte os EditText para int
        int i_dois_zero = Integer.parseInt(str_dois_zero); // converte os EditText para int
        int i_dois_um = Integer.parseInt(str_dois_um); // converte os EditText para int
        int i_dois_dois = Integer.parseInt(str_dois_dois); // converte os EditText para int

        int principal = i_zero_zero * i_um_um * i_dois_dois +
                i_zero_um * i_um_dois * i_dois_zero +
                i_zero_dois * i_um_zero * i_dois_um;

        int secundaria = i_zero_um * i_um_zero * i_dois_dois +
                i_zero_zero * i_um_dois * i_dois_um +
                i_zero_dois * i_um_um * i_dois_zero;

        int determinante = principal-secundaria;
        if (determinante < 0){
            determinante = determinante*-1;
        }
        result.setText("Resultado: "+determinante);
        result.setVisibility(View.VISIBLE);
    }
    public void esconder_teclado_botao(View v) { // esconde o teclado ao clicar no botão para calcular resultado
        InputMethodManager imm = (InputMethodManager) this.getSystemService(this.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        checar_preenchimento();
    }
    public void esconder_teclado(View a) { // esconde o teclado ao clicar na tela
        InputMethodManager imm = (InputMethodManager) this.getSystemService(this.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(a.getWindowToken(), 0);
    }
    /*
    public void criar_matriz(){
            int[][] aux_matrix = {{9,8,7},{4,5,6},{3,1,2}};
            String n = "Matriz\n";
            for (int i = 0; i < 3; i++){
                for (int j = 0; j < 3; j++){
                    n += aux_matrix[i][j]+"  ";
                }
                n += "\n";
        }
        matrix.setText(n);
    } */
}
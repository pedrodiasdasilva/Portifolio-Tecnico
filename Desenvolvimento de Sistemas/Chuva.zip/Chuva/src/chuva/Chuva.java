package chuva;

import java.util.Scanner;

public class Chuva {

    
    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);
            final int Maximo = 1000000;
                int N = Sc.nextInt();
                int S = Sc.nextInt();
                long Resultado = 0;
                int[] ResultadoSoma = new int[Maximo];
                int somar = 0;
                ResultadoSoma[0] = 1;
                
                for(int A=0; A<N; A++){
                    int y = Sc.nextInt();
                    somar += y;
                    if(somar - S >=0){
                        Resultado += ResultadoSoma[somar - S];
                        ResultadoSoma[somar]++;
                        
                    
                    }
                    System.out.println(Resultado);
                
                }
    }
    
}

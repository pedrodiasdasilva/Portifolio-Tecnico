package maiorvalor;

import java.util.Scanner;
public class MaiorValor {

    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);
            int N = Sc.nextInt();
            int M = Sc.nextInt();
            int S = Sc.nextInt();
            boolean encontrar = false;
            int resposta = 0;
            
        for (int i=M; i>N; i--) {
                int somar = 0;
                int A = i;
            while (A > 0) {
		somar += A % 10;
		A /= 10;
            }if (somar == S) {
		encontrar = true;
		resposta = i;
            break;
            }
	}	    
       if (encontrar)
        System.out.println(resposta);
            else
                System.out.println(-1);
            
    }
    
}

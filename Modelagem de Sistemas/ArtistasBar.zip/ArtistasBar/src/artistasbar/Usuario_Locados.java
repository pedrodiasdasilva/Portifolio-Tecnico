
package artistasbar;


public class Usuario_Locados {
    String propaganda;
    String ingressos_disponiveis;
   
    
}


package artistasbar;

public class Restaurantes {
    String Nome;
    String endereco;
    String dias_disponiveis;

    public Restaurantes(String Nome, String endereco, String dias_disponiveis) {
        this.Nome = Nome;
        this.endereco = endereco;
        this.dias_disponiveis = dias_disponiveis;
    }
    
}

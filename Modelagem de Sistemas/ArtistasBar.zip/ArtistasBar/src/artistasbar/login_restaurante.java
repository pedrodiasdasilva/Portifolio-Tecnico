
package artistasbar;


public class login_restaurante {
    int valores;
    String capacidade_de_publico;
    String quantos_shows_ja_fez;

    public login_restaurante(int valores, String capacidade_de_publico, String quantos_shows_ja_fez) {
        this.valores = valores;
        this.capacidade_de_publico = capacidade_de_publico;
        this.quantos_shows_ja_fez = quantos_shows_ja_fez;
    }
    
}

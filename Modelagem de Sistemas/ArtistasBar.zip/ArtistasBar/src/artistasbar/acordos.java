
package artistasbar;


public class acordos {
    String cache;
    String data;
    String genero;

    public acordos(String cache, String data, String genero) {
        this.cache = cache;
        this.data = data;
        this.genero = genero;
    }
    public void fazer_show(){


    }
    public void servir(){
    
    
    }
    public void vender_ingressos(){
    
    
    }
   public void organizar_tudo(){
   
   
   }
  
}

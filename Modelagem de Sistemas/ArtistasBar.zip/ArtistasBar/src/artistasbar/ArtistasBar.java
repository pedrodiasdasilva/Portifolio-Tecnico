package artistasbar;


public class ArtistasBar {

   
    public static void main(String[] args) {
        
    }
    
}

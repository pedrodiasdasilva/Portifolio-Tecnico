
package artistasbar;

public class login_banda {
    String quantos_shows_ja_fez;
    String aonde_ja_tocou;
    String quanto_tempo_de_banda;
    String genero;

    public login_banda(String quantos_shows_ja_fez, String aonde_ja_tocou, String quanto_tempo_de_banda, String genero) {
        this.quantos_shows_ja_fez = quantos_shows_ja_fez;
        this.aonde_ja_tocou = aonde_ja_tocou;
        this.quanto_tempo_de_banda = quanto_tempo_de_banda;
        this.genero = genero;
    }
    
}

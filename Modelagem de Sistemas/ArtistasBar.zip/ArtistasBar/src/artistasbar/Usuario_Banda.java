
package artistasbar;


public class Usuario_Banda {
    String horarios_banda;
    String valores_banda;
    String disponibilidade_banda;
    String telefone_banda;
    String genero;

    public Usuario_Banda(String horarios_banda, String valores_banda, String disponibilidade_banda, String telefone_banda, String genero) {
        this.horarios_banda = horarios_banda;
        this.valores_banda = valores_banda;
        this.disponibilidade_banda = disponibilidade_banda;
        this.telefone_banda = telefone_banda;
        this.genero = genero;
    }
    
}

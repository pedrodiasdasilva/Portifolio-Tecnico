
package artistasbar;

public class Bandas {
    String nome;
    int numero_de_integrantes;
    String tipo_musica;

    public Bandas(String nome, int numero_de_integrantes, String tipo_musica) {
        this.nome = nome;
        this.numero_de_integrantes = numero_de_integrantes;
        this.tipo_musica = tipo_musica;
    }
    
}

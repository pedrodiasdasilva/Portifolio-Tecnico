
package artistasbar;


public class Compras {
    String valor_final_ingresso;
    String direitos;
    String show_selecionado;

    public Compras(String valor_final_ingresso, String direitos, String show_selecionado) {
        this.valor_final_ingresso = valor_final_ingresso;
        this.direitos = direitos;
        this.show_selecionado = show_selecionado;
    }
    
    public void comprar_ingressos(){
    
    
    }
    public void ir_no_show(){
        
        
    }
    public void se_cadastrar(){
    
    
    
    }
    public void pagar_ingresso(){
    
    
    }
}


package artistasbar;

public class Shows {
    String data_marcada;
    String hora_marcada;
    String nome_de_pessoas;
    String preco_ingresso;

    public Shows(String data_marcada, String hora_marcada, String nome_de_pessoas, String preco_ingresso) {
        this.data_marcada = data_marcada;
        this.hora_marcada = hora_marcada;
        this.nome_de_pessoas = nome_de_pessoas;
        this.preco_ingresso = preco_ingresso;
    }
    
}

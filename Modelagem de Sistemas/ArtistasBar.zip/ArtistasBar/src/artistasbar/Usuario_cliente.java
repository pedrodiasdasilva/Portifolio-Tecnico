
package artistasbar;

public class Usuario_cliente {
    String nome;
    String idade;
    String cpf;
    String show_desejado;
    String forma_de_pagamento;

    public Usuario_cliente(String nome, String idade, String cpf, String show_desejado, String forma_de_pagamento) {
        this.nome = nome;
        this.idade = idade;
        this.cpf = cpf;
        this.show_desejado = show_desejado;
        this.forma_de_pagamento = forma_de_pagamento;
    }
    
}

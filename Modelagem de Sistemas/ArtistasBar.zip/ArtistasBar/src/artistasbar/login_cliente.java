
package artistasbar;


public class login_cliente {
    String quantos_shows_ja_foi;
    String genero_favorito;

    public login_cliente(String quantos_shows_ja_foi, String genero_favorito) {
        this.quantos_shows_ja_foi = quantos_shows_ja_foi;
        this.genero_favorito = genero_favorito;
    }
    
}
